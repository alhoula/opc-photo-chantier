import { getStore } from "@netlify/blobs";

const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

export const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "POST only" }) };

  try {
    const serie = JSON.parse(event.body || "{}");
    if (!serie.id || !serie.date || !serie.projectName || !serie.buildingName || !serie.level || !serie.lot) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "Données série incomplètes" }) };
    }

    const store = getStore("opc-series");
    await store.set(`series/${serie.id}.json`, JSON.stringify({
      ...serie,
      savedAt: new Date().toISOString()
    }), {
      metadata: {
        date: serie.date,
        projectName: serie.projectName,
        buildingName: serie.buildingName,
        lot: serie.lot
      }
    });

    return { statusCode: 200, headers, body: JSON.stringify({ ok: true, id: serie.id }) };
  } catch (error) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: error.message || "Erreur sauvegarde série" }) };
  }
};
