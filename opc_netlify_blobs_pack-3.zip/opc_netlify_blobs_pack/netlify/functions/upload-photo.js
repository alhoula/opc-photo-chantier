import { getStore } from "@netlify/blobs";

const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

export const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "POST only" }) };

  try {
    const body = JSON.parse(event.body || "{}");
    const { photoId, dataUrl, meta = {} } = body;

    if (!photoId || !dataUrl || !String(dataUrl).startsWith("data:image/")) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "photoId/dataUrl invalides" }) };
    }

    const store = getStore("opc-photos");
    await store.set(photoId, dataUrl, {
      metadata: {
        ...meta,
        createdAt: new Date().toISOString()
      }
    });

    return { statusCode: 200, headers, body: JSON.stringify({ ok: true, photoId }) };
  } catch (error) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: error.message || "Erreur upload photo" }) };
  }
};
