import { getStore } from "@netlify/blobs";

const headers = {
  "Access-Control-Allow-Origin": "*",
  "Content-Type": "application/json"
};

export const handler = async (event) => {
  try {
    const photoId = event.queryStringParameters?.id;
    if (!photoId) return { statusCode: 400, headers, body: JSON.stringify({ error: "id photo requis" }) };

    const store = getStore("opc-photos");
    const dataUrl = await store.get(photoId);
    if (!dataUrl) return { statusCode: 404, headers, body: JSON.stringify({ error: "Photo introuvable" }) };

    return { statusCode: 200, headers, body: JSON.stringify({ ok: true, photoId, dataUrl }) };
  } catch (error) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: error.message || "Erreur lecture photo" }) };
  }
};
