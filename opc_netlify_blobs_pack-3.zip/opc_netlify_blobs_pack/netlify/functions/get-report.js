import { getStore } from "@netlify/blobs";

const headers = {
  "Access-Control-Allow-Origin": "*",
  "Content-Type": "application/json"
};

export const handler = async (event) => {
  try {
    const date = event.queryStringParameters?.date;
    if (!date) return { statusCode: 400, headers, body: JSON.stringify({ error: "date requise" }) };

    const store = getStore("opc-series");
    const list = await store.list({ prefix: "series/" });
    const blobs = list.blobs || [];
    const rows = [];

    for (const blob of blobs) {
      const txt = await store.get(blob.key);
      if (!txt) continue;
      try {
        const serie = JSON.parse(txt);
        if (serie.date === date) rows.push(serie);
      } catch {}
    }

    rows.sort((a,b)=>
      String(a.projectName || "").localeCompare(String(b.projectName || "")) ||
      String(a.buildingName || "").localeCompare(String(b.buildingName || "")) ||
      String(a.level || "").localeCompare(String(b.level || "")) ||
      String(a.lot || "").localeCompare(String(b.lot || ""))
    );

    return { statusCode: 200, headers, body: JSON.stringify({ ok: true, date, series: rows }) };
  } catch (error) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: error.message || "Erreur rapport" }) };
  }
};
