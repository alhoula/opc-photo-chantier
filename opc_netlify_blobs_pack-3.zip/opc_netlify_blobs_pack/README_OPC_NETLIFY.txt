PACK NETLIFY - OPC Photo Chantier

Objectif :
- index.html = application
- netlify/functions/upload-photo.js = envoie les photos vers Netlify Blobs
- netlify/functions/save-serie.js = enregistre les séries photo
- netlify/functions/get-report.js = récupère les séries par date
- netlify/functions/get-photo.js = récupère les photos
- package.json = dépendance @netlify/blobs
- netlify.toml = configuration Netlify

Déploiement :
1) Dézipper ce dossier.
2) Glisser le dossier complet sur Netlify, ou connecter à GitHub.
3) Netlify installe automatiquement @netlify/blobs.
4) Ouvrir le site Netlify.
5) Créer projet, immeuble, niveau, puis suivi photo.
6) Les photos sont envoyées vers Netlify Blobs, pas stockées dans la mémoire du téléphone.

Important :
- Cette version a besoin d’internet pour enregistrer les photos.
- Le rapport lit les photos stockées en ligne.
- Si Functions ou Blobs dépassent les limites du plan gratuit, passer au plan supérieur.
